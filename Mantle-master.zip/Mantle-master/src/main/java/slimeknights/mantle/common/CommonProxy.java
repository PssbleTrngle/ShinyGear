package slimeknights.mantle.common;

public class CommonProxy {
    public void preInit() {
    }
}
